import subprocess

subprocess.call(['ls'])